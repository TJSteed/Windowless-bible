#!/usr/local/bin/python3
import tkinter
import tkinter as tk
from PIL import ImageTk, Image
import os
from tkinter import *
window = Tk() 

window.title('Windowless_Bible')
window.configure(bg='#ffffff')
window.minsize(100,100)
window.geometry("480x480")
window.attributes("-alpha", 0.3)
window.iconbitmap('cross.ico')
import tkinter as tk
from PIL import ImageTk, Image

#This creates the main window of an application

path = "r.jpg"

#Creates a Tkinter-compatible photo image, which can be used everywhere Tkinter expects an image object.
img = ImageTk.PhotoImage(Image.open(path))

#The Label widget is a standard Tkinter widget used to display a text or image on the screen.
panel = tk.Label(window, image = img)

#The Pack geometry manager packs widgets in rows or columns.
panel.pack(side = "bottom", fill = "both", expand = "yes")

#Start the GUI
window.mainloop()

def set_menu(window, choices):
    menubar = tkinter.Menu(window)
    window.config(menu=menubar)

    def _set_choices(menu, choices):
        for label, command in choices.items():
            if isinstance(command, dict):
                # Submenu
                submenu = tkinter.Menu(menu)
                menu.add_cascade(label=label, menu=submenu)
                _set_choices(submenu, command)
            elif label == '-' and command == '-':
                # Separator
                menu.add_separator()
            else:
                # Simple choice
                menu.add_command(label=label, command=command)

    _set_choices(menubar, choices)


if __name__ == '__main__':
    import sys
    window.mainloop()
